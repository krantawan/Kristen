export default function Footer() {
    return (
        <footer className="text-xs text-muted-foreground mt-6 mb-6 text-center opacity-80">
  Made with ❤️ by Kalafia
</footer>
    );
}