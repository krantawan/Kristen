import type { ReactNode } from "react";
import { Roboto, Prompt } from "next/font/google";
import "./globals.css";

const roboto = Roboto({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-roboto",
});

const prompt = Prompt({
  subsets: ["latin", "thai"],
  weight: ["400", "700"],
  variable: "--font-prompt",
});

export default function RootLayout({
  children,
  params: { locale },
}: {
  children: ReactNode;
  params: { locale: string };
}) {
  const fontClass = locale === "th" ? prompt.variable : roboto.variable;

  return (
    <html lang={locale}>
      <body className={`${fontClass} antialiased`}>{children}</body>
    </html>
  );
}

export function generateStaticParams() {
  return [{ locale: "en" }, { locale: "th" }];
}
