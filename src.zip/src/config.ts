export const locales = ["en", "th"] as const;
